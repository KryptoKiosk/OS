cp -p /tmp/extract/package/manatee/N7G1/bin/* /usr/bin
cp -p /tmp/extract/package/manatee/N7G1/lib/* /usr/lib
